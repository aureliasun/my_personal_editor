## 稿件检查报告 / Manuscript Check Report

**稿件标题 / Manuscript Title**: [Title]
**检测语言 / Detected Language**: [Chinese / English]
**检测领域 / Detected Domain**: [Domain Name]
**检查日期 / Check Date**: [Date]

---

### 总体评价 / Overall Assessment

[2-3句话概述稿件当前状态、整体质量和主要问题类别。]
[2-3 sentences summarizing the manuscript's current state, overall quality, and main categories of issues.]

---

### 严重问题 / Critical Issues

> 以下问题必须在投稿前修复 / The following issues MUST be fixed before submission

#### 1. 引用问题 / Citation Issues
- **[位置/Location]**: [具体位置描述]
- **问题/Problem**: [问题描述]
- **建议修复/Suggested Fix**: [具体修复建议]

#### 2. 数据问题 / Data Issues
- **[位置/Location]**: [具体位置描述]
- **问题/Problem**: [问题描述]
- **建议修复/Suggested Fix**: [具体修复建议]

#### 3. 编造/可疑内容 / Fabrication/Suspicious Content
- **[位置/Location]**: [具体位置描述]
- **问题/Problem**: [问题描述]
- **建议修复/Suggested Fix**: [具体修复建议]

---

### 中等问题 / Moderate Issues

> 以下问题建议在修改稿中解决 / The following issues should be addressed in the revision

1. [问题描述] → [修改建议]
2. [问题描述] → [修改建议]
3. ...

---

### 建议改进 / Minor Improvements

> 以下为锦上添花的改进建议 / The following are nice-to-have improvements

- [建议1]
- [建议2]
- ...

---

### 语言修改清单 / Language Corrections

| 序号 | 原文 / Original | 修改后 / Corrected | 理由 / Reason |
|------|----------------|-------------------|---------------|
| 1 | ... | ... | ... |
| 2 | ... | ... | ... |

---

### 检查总结 / Check Summary

| 检查维度 | 状态 | 问题数量 |
|----------|------|----------|
| 引用准确性 / Citation Accuracy | ✅/⚠️/❌ | N |
| 数据真实性 / Data Integrity | ✅/⚠️/❌ | N |
| 编造检测 / Fabrication Detection | ✅/⚠️/❌ | N |
| 语言质量 / Language Quality | ✅/⚠️/❌ | N |

**总体可投稿性 / Overall Submittability**: [可以投稿 / 需要修改后投稿 / 需要重大修改]
