## 稿件评估报告 / Manuscript Evaluation Report

**稿件标题 / Manuscript Title**: [Title]
**检测语言 / Detected Language**: [Chinese / English]
**检测领域 / Detected Domain**: [Domain Name]
**评估日期 / Evaluation Date**: [Date]

---

### 总体评价 / Overall Assessment

[3-4段详细评估，涵盖：]
[3-4 paragraphs covering:]

1. **研究问题的重要性**: 这个研究问题为什么重要？它填补了什么空白？
2. **方法论评价**: 研究设计是否合理？方法是否恰当？
3. **贡献与创新**: 论文的主要贡献是什么？创新性如何？
4. **整体印象**: 总体评价和投稿准备程度。

---

### 评分概览 / Score Overview

| 评估维度 / Dimension | 评分 / Score (1-10) | 说明 / Comments |
|----------------------|---------------------|-----------------|
| 创新性 / Novelty | X/10 | ... |
| 研究问题 / Research Question | X/10 | ... |
| 文献综述 / Literature Review | X/10 | ... |
| 方法论 / Methodology | X/10 | ... |
| 数据质量 / Data Quality | X/10 | ... |
| 分析与论证 / Analysis & Argumentation | X/10 | ... |
| 写作质量 / Writing Quality | X/10 | ... |
| 结构逻辑 / Structure & Logic | X/10 | ... |
| 学术规范 / Academic Standards | X/10 | ... |
| **综合评分 / Overall** | **X/10** | |

---

### 按章节的具体修改建议 / Section-by-Section Suggestions

#### 标题与摘要 / Title & Abstract
- [具体建议1]
- [具体建议2]

#### 引言 / Introduction
- [具体建议1]
- [具体建议2]

#### 文献综述 / Literature Review
- [具体建议1]
- [具体建议2]

#### 方法 / Methods
- [具体建议1]
- [具体建议2]

#### 结果 / Results
- [具体建议1]
- [具体建议2]

#### 讨论 / Discussion
- [具体建议1]
- [具体建议2]

#### 结论 / Conclusion
- [具体建议1]
- [具体建议2]

---

### 领域特定建议 / Domain-Specific Suggestions

> 基于 [领域名] 领域的专业审稿标准提供的建议
> Suggestions based on domain-specific review standards for [Domain]

- [领域特定建议1]
- [领域特定建议2]
- ...

---

### 关键修改建议（按优先级排序）/ Key Revision Suggestions (Prioritized)

1. **🔴 最高优先级 / Highest Priority**
   - [问题]: [详细描述]
   - [建议]: [具体修改方案]

2. **🟠 高优先级 / High Priority**
   - [问题]: [详细描述]
   - [建议]: [具体修改方案]

3. **🟡 中等优先级 / Medium Priority**
   - [问题]: [详细描述]
   - [建议]: [具体修改方案]

4. **🟢 低优先级 / Low Priority**
   - [问题]: [详细描述]
   - [建议]: [具体修改方案]

---

### 期刊匹配建议 / Journal Fit Suggestions

| 推荐期刊 / Journal | 匹配度 / Fit | 说明 / Rationale |
|--------------------|-------------|-----------------|
| [期刊名1] | 高/中/低 | [推荐理由] |
| [期刊名2] | 高/中/低 | [推荐理由] |
| [期刊名3] | 高/中/低 | [推荐理由] |

---

### 评估总结 / Evaluation Summary

**投稿准备度 / Submission Readiness**: [可直接投稿 / 修改后可投稿 / 需要重大修改 / 建议更换方向]

**最需要改进的3个方面 / Top 3 Areas for Improvement**:
1. [方面1]
2. [方面2]
3. [方面3]

**论文最大亮点 / Greatest Strengths**:
1. [亮点1]
2. [亮点2]
