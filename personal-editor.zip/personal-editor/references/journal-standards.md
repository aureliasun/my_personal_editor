# 期刊审稿标准参考 / Journal Review Standards Reference

## 通用审稿标准 / Universal Review Criteria

### 1. 原创性与创新性 / Originality & Novelty
- 研究问题是否新颖？
- 是否提供了新的理论视角、方法或实证发现？
- 与已有文献的区别是否明确？

### 2. 方法论严谨性 / Methodological Rigor
- 研究设计是否适当？
- 数据收集方法是否可靠？
- 分析方法是否正确应用？
- 结论是否得到数据的充分支持？

### 3. 学术贡献 / Scholarly Contribution
- 对理论发展的贡献
- 对实践的启示
- 对政策的影响
- 对方法论的推进

### 4. 写作与表达 / Writing & Presentation
- 结构是否清晰？
- 逻辑是否连贯？
- 语言是否准确、规范？
- 图表是否有效传达信息？

### 5. 学术规范 / Academic Standards
- 引用是否完整、准确？
- 伦理规范是否遵守？
- 数据和方法是否透明、可重复？

---

## 不同期刊类型的特殊要求 / Special Requirements by Journal Type

### 顶刊 / Top-Tier Journals
- 要求高度原创性和理论贡献
- 方法论要求极为严格
- 需要明确说明研究的普遍意义
- 字数限制通常较严格

### 领域专业期刊 / Field-Specific Journals
- 要求深入的领域专业知识
- 方法论标准与领域惯例一致
- 需要与领域内核心文献充分对话

### 方法论期刊 / Methods Journals
- 要求方法论上的创新或改进
- 需要详细的方法描述和验证
- 通常需要模拟数据或复制研究来验证方法

---

## 中文期刊 vs 英文期刊的差异 / Differences Between Chinese and English Journals

### 中文期刊特点
- 通常要求更详细的文献综述
- 政策建议部分通常被高度重视
- 对中国情境的讨论不可或缺
- 注重理论与实践的结合
- 部分期刊对参考文献数量有要求

### 英文期刊特点
- 更强调研究问题的理论框架
- 对方法论的描述要求更详细
- 更注重与国际文献的对话
- 对研究局限性的讨论更重视
- 更强调研究的可重复性

---

## 常见拒稿原因 / Common Reasons for Rejection

1. **超出期刊范围** (Out of Scope)
2. **创新性不足** (Insufficient Novelty)
3. **方法论缺陷** (Methodological Flaws)
4. **数据不充分** (Insufficient Data)
5. **结论过度推断** (Overclaiming)
6. **写作质量差** (Poor Writing Quality)
7. **文献综述不全面** (Inadequate Literature Review)
8. **研究设计不匹配** (Mismatched Research Design)
9. **伦理问题** (Ethical Concerns)
10. **格式不规范** (Formatting Issues)
