# 常见学术写作错误案例 / Common Academic Writing Errors

## 引用相关 / Citation-Related

### 1. 引用与参考文献不匹配
- 正文中引用了 (Smith, 2020)，但参考文献列表中没有该条目
- 参考文献列表中有 Jones (2019)，但正文中从未引用

### 2. 引用格式不一致
- 同一篇论文中混用 APA 和 IEEE 格式
- 同一作者的姓名格式不统一 (e.g., "Wang" vs "Wang, L." vs "Wang, L.-J.")

### 3. 过度自我引用
- 自引比例超过 30% 而无合理解释
- 引用自己的未发表作品而未标注

### 4. 引用二手文献
- 引用了原始文献的转引，但未注明 "as cited in"

---

## 数据相关 / Data-Related

### 1. 内部数据不一致
- 正文中说 "共调查了500人"，但方法部分说 "样本量为480"
- 表1中某列总和不等于文中报告的总数
- 百分比加总不等于100%

### 2. 统计报告不规范
- 只报告 p < 0.05 而不报告具体 p 值
- 不报告效应量 (effect size)
- 不报告置信区间
- F值/χ²值与对应的 p 值不匹配

### 3. 图表与正文矛盾
- 图中显示增长趋势，正文却说 "呈下降趋势"
- 表中数据与正文描述的数值不同

---

## 逻辑相关 / Logic-Related

### 1. 因果推断过度
- "A与B相关" → 错误推论 "A导致B"
- 忽视混淆变量和反向因果

### 2. 以偏概全
- 仅基于个案就做出普遍性结论
- 样本仅来自一个地区却推论全国

### 3. 循环论证
- 用结论来证明前提
- 定义中隐含了待证明的结论

---

## 语言相关 / Language-Related

### 英文常见错误 / Common English Errors
- Subject-verb disagreement: "The data shows" → "The data show"
- Dangling modifiers: "Using this method, the results were..."
- Incorrect tense in literature review: "Smith found" vs "Smith finds"
- Overuse of passive voice
- Inconsistent use of Oxford comma
- "Which" vs "that" confusion
- Run-on sentences

### 中文常见错误 / Common Chinese Errors
- "的、地、得"混用: "高兴的跑" → "高兴地跑"
- 主语残缺: "通过...使..."结构
- 语序不当: 多重定语排列顺序错误
- 口语化表达出现在学术论文中
- 中英文混排格式不规范: "使用SPSS软件" → "使用 SPSS 软件"
- 量词误用: "一个研究" → "一项研究"
- 长句缺乏标点断句，导致表意不清

---

## 学术规范相关 / Academic Standards

### 1. 伦理声明缺失
- 涉及人类受试者的研究未说明伦理审查
- 未说明知情同意获取过程

### 2. 利益冲突未声明
- 未披露资助来源
- 未声明潜在利益冲突

### 3. 数据可用性
- 未说明数据是否可公开获取
- 未提供数据访问方式或DOI
